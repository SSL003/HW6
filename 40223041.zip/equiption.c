//Sajjad Salimi 40223041

#include <stdio.h>
#include <math.h>

float solver(float i, float j, float k, float *root1, float *root2);
int main()
{
 float a,b,c;
 printf("Enter three numbers\n");
 scanf("%f%f%f", &a,&b,&c);
 if (a==0 && b==0)
 printf("Wrong order!\n");
 else
 {
  float *p1,*p2;
  if (solver(a,b,c,p1,p2)==1)
  printf("This equation has a real root and its\
  value is equal to: %f", *p1);
  else if (solver(a,b,c,p1,p2)==2)
  printf("This equiption has two real roots and\
  their values are equal to: %f and %f", *p1,*p2);
  else if (solver(a,b,c,p1,p2)==3)
  printf("This equiption has a double real root and\
  its value is equal to: %f",*p1);
  else
  printf("This equation has no real root");
 }
return 0;
}

float solver(float i, float j, float k, float *root1, float *root2)
{
 if (i==0)
 {
 *root1 = (float)-k/j;
 return 1;
 }
 else
 {
  float delta = j*j-4*i*k;
  *root1 = (-j+sqrt(delta))/(2*i);
  *root2 = (-j-sqrt(delta))/(2*i);

  if (delta>0)
  return 2;

  else if (delta==0)
  return 3;
  
  else 
  return 0;
 }
}